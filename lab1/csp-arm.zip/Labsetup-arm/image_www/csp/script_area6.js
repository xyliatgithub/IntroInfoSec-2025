document.getElementById('area6').innerHTML = "<font color='green'>OK</font>";
